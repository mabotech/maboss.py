import Pyro.core

import OpenOPC





class OPCClient(object):
    
    def __init__(self):
        pass
        
        
    def connect(self):
        pass
        
        
    def write(self):
        pass
        
    def read(self):
        pass
        