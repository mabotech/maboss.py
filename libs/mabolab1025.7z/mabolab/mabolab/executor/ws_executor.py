

def execute(args):
    
    return args