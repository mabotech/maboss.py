# -*- coding: utf-8 -*-

APP_CONFIG_FILE = 'mabo.ini'

LOGGING_CONFIG_FILE = 'logging.ini'
