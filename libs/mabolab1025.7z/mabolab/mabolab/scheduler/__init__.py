


#inverval

def daily(starton):
    pass
    
def weekly(starton, days):
    pass